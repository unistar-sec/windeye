#coding: utf-8
from camera.config import db
from camera.config import Camera
 
#查询User表中所有数据
#print User.query.all() #User模型配置了默认返回username列数据,所以这里会username列数据

all_data = []
ans = []
#查询出所有数据
class select():
	global all_data, ans
	all_data = Camera.query.all()
	#print(len(all_data))
	for data in all_data:
		dic = dict(ID = data.num, 
					NAME = data.name,
					IP = data.ip,
					PORTS = data.ports,
					REMARK = data.remark)
		ans.append(dic)
	print(ans)

if __name__ == '__main__':
	select()
