# coding:utf-8
# 数据库配置文件
 
from flask import Flask
from flask_sqlalchemy import SQLAlchemy
import os
 
#配置数据库
basedir = os.path.abspath(os.path.dirname(__file__))
app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///' + os.path.join(basedir, 'camera.sqlite') 
app.config['SQLALCHEMY_COMMIT_ON_TEARDOWN'] = True
db = SQLAlchemy(app)
#print("ok1") 
#定义User模型
class Camera(db.Model):
              
              __tablename__ = 'Camera'                                      #表名
              
              num = db.Column(db.String, primary_key=True)                 #列名nun,int类型,主键
              name = db.Column(db.String(64), unique=True, index=True) #列名name,str类型,不允许重复出现,创建索引
              ip = db.Column(db.String)                                  #列名ip
              ports = db.Column(db.String(200))
              remark = db.Column(db.String(200))
#print("ok2") 