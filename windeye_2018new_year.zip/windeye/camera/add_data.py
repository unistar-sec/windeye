#coding: utf-8
from config import db
from config import Camera
     
db.drop_all()  #删除数据库
db.create_all() #创建数据库
 
#定义要增加的数据
c_2 = Camera(num='2', name='海康威视DS-2CD7026FWD-(A)', ip='175.17.9.1', ports='80,443,554,21', remark='')
c_3 = Camera(num='3', name='大华DH-IPC-HFW1225M-I1', ip='212.45.3.20', ports='80,37212,21,3306', remark='')
c_4 = Camera(num='4', name='UPS Camera Floor 2', ip='12.41.222.19', ports='80,37212,21,3306', remark='')
 
#添加到会话
db.session.add(c_2)
db.session.add(c_3)
db.session.add(c_4)
#提交会话
db.session.commit()