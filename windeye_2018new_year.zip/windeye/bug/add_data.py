#coding: utf-8
from config import db
from config import Bug
     
db.drop_all()  #删除数据库
db.create_all() #创建数据库
 
#定义要增加的数据
b_2 = Bug(num='2', name='Geovision IP摄像头修改admin权限的用户名和密码和远程命令执行漏洞', category='命令执行', level='严重', remark='GV-BX1500和GV-MFD1501')
b_3 = Bug(num='3', name='Vivotek系列网络摄像头存在远程栈溢出漏洞漏洞', category='缓冲区溢出', level='高危', remark='中国晶睿通讯（VIVOTEK）公司的网络摄像机产品')
b_4 = Bug(num='4', name='海康威视旗下萤石工作室PC客户端存在DLL劫持漏洞', category='DLL劫持漏洞', level='中危', remark='一款基于视频应用的PC客户端')
 
#添加到会话
db.session.add(b_2)
db.session.add(b_3)
db.session.add(b_4)
#提交会话
db.session.commit()