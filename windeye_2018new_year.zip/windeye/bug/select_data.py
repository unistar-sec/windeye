#coding: utf-8
from bug.config import db
from bug.config import Bug
 
#查询User表中所有数据
#print User.query.all() #User模型配置了默认返回username列数据,所以这里会username列数据

all_data = []
ans2 = []
#查询出所有数据
class select():
	global all_data, ans2
	all_data = Bug.query.all()
	#print(len(all_data))
	for data in all_data:
		dic = dict(ID = data.num, 
					NAME = data.name,
					CATEGORY = data.category,
					LEVEL = data.level,
					REMARK = data.remark)
		ans2.append(dic)
	print(ans2)

if __name__ == '__main__':
	select()
