#coding: utf-8
from flask import Flask, render_template, redirect, url_for
from flask import request
from camera.select_data import select, all_data, ans
from bug.select_data import select, all_data, ans2
app = Flask(__name__) 

@app.route('/')
def index():
	return render_template("index.html",
	ctrl_center = "ctrl_center", 
	device_load = "device_load", 
	bug_load = "bug_load",
	index = "index",
	sign_in = "sign_in",
	profile = "profile",
	notice = "notice",
	about = "about",
	bug_net = "bug_net")

@app.route('/ctrl_center')
def ctrl_center():
	ip = request.remote_addr
	return render_template("ctrl_center.html", user_ip = ip,
	ctrl_center = "ctrl_center", 
	device_load = "device_load", 
	bug_load = "bug_load",
	index = "index",
	sign_in = "sign_in",
	profile = "profile",
	notice = "notice",
	about = "about",
	bug_net = "bug_net")

@app.route('/sign_in', methods=['POST','GET'])
def sign_in():
	error = None
	if request.method == 'POST':
		if request.form['u']=='admin' and request.form['p']=='admin':
			return redirect(url_for('ctrl_center',username=request.form['u']))
		else:
			error = 'Invalid username/password'
			
	return render_template("/login/sign_in.html", error = error, 
	ctrl_center = "ctrl_center", 
	device_load = "device_load", 
	bug_load = "bug_load",
	index = "index",
	sign_in = "sign_in",
	profile = "profile",
	notice = "notice",
	about = "about",
	bug_net = "bug_net")
	
@app.route('/device_load')
def device_load():
	return render_template("device_load.html", 
	ctrl_center = "ctrl_center",
	device_load = "device_load", 
	bug_load = "bug_load",
	bug_net = "bug_net",
	index = "index",
	sign_in = "sign_in",
	profile = "profile",
	notice = "notice",
	about = "about",
	cameras = ans)

@app.route('/about')
def about():
	return render_template("about.html", 
	ctrl_center = "ctrl_center",
	device_load = "device_load", 
	bug_load = "bug_load",
	bug_net = "bug_net",
	index = "index",
	sign_in = "sign_in",
	profile = "profile",
	notice = "notice",
	about = "about")
	
@app.route('/bug_load')
def bug_load():
	return render_template("bug_load.html",
	ctrl_center = "ctrl_center", 
	device_load = "device_load", 
	bug_load = "bug_load",
	index = "index",
	sign_in = "sign_in",
	bug_net = "bug_net",
	profile = "profile",
	notice = "notice",
	about = "about",
	bugs = ans2)

@app.route('/bug_net')
def bug_net():
	return render_template("bug_net.html",
	ctrl_center = "ctrl_center", 
	device_load = "device_load", 
	bug_load = "bug_load",
	index = "index",
	sign_in = "sign_in",
	profile = "profile",
	notice = "notice",
	about = "about",
	bug_net = "bug_net")

@app.route('/notice', methods=['POST','GET'])
def notice():
	return render_template("notice.html",
	ctrl_center = "ctrl_center", 
	device_load = "device_load", 
	bug_load = "bug_load",
	index = "index",
	sign_in = "sign_in",
	profile = "profile",
	notice = "notice",
	about = "about",
	bug_net = "bug_net")

@app.route('/profile', methods=['POST','GET'])
def profile():
	return render_template("profile.html",
	ctrl_center = "ctrl_center", 
	device_load = "device_load", 
	bug_load = "bug_load",
	index = "index",
	sign_in = "sign_in",
	profile = "profile",
	about = "about",
	notice = "notice",
	bug_net = "bug_net")

if __name__ == '__main__':
	#app.run(debug=True)
	app.run(host = '0.0.0.0', port = 80)
	app.run(host='0.0.0.0', port=80)